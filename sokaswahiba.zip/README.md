# SokaSwahiba Bot

Hii ni WhatsApp bot rahisi inayojibu ujumbe wa "ratiba" na "mechi" kwa kutumia WhatsApp Cloud API.

## Features
- Ukituma neno `ratiba` → utapata ratiba ya mechi.
- Ukituma neno `mechi` → utapata taarifa ya mechi inayofuata.
- Ukikosea au kuandika kitu kingine, bot itakuambia hajakuelewa.

## Installation
1. Clone au upload project hii kwenye server (Render, Railway, etc).
2. `npm install`
3. Badilisha sehemu ya `ACCESS_TOKEN` kwenye `server.js` na token yako kutoka Meta.
4. `npm start` kuendesha bot.

## Notes
- Hakikisha Webhook URL yako iko live na imethibitishwa kwenye Meta Developers Dashboard.
- Hakikisha Access Token yako iko active na phone number ID ni sahihi.